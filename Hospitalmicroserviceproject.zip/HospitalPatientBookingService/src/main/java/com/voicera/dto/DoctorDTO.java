package com.voicera.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.voicera.entity.AvailableTime;
import com.voicera.entity.Department;
import com.voicera.entity.Role;

import lombok.Data;

@Data
public class DoctorDTO {


    private String name;
    private List<ContactInfoDTO> contactInfo;
    private Department department;
    private String imagename;
    @JsonIgnore
    private byte[] image;
    private AvailableTime availableTime;
    private Role role;
    private boolean accountActive;
 
}
