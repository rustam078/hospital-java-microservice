package com.voicera.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class UserDTO {

	private Long id;
    @NotBlank(message = "Username cannot be blank")
    @Size(min =5, max = 20, message = "Username must be between 5 and 20 characters")
    private String username;
    
    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Invalid email format")
    @Column(nullable = false, unique = true)
    private String email;

    @NotBlank(message = "Password cannot be blank")
    @Size(min = 8, message = "Password must be at least 8 characters")
    private String password;

    private List<RoleDTO> roles ;
    
    private String imagename;
    @JsonIgnore
    private byte[] image;

    private boolean isActive;

	
	
    
    
}
