package com.voicera.dto;

import com.voicera.entity.UserRole;

import lombok.Data;

@Data
public class RoleDTO {
	
    private UserRole name;
}
