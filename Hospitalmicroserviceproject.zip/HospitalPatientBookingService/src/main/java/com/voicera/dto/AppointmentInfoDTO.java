package com.voicera.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class AppointmentInfoDTO {
	private long id;
	private String patientname;
	private String patientimage;
	private String doctorname;
	private String doctorimage;
	private String department;
    private LocalDateTime appointmentTime; 
	private String  cause;
    private String type;
    private String value;
}
