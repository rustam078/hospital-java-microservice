package com.voicera.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.voicera.dto.DoctorDTO;

@FeignClient(name = "DoctorService",url = "http://localhost:8082/doctor-service/api")  // Specify the name of the Feign client
public interface DoctorFeignClient {

	@GetMapping("/{doctorId}")
	public ResponseEntity<DoctorDTO> getDoctorById(@PathVariable Long doctorId);
}

