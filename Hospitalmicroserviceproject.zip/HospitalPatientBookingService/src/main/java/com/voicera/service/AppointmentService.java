package com.voicera.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.voicera.dto.AppointmentInfoDTO;
import com.voicera.dto.DoctorDTO;
import com.voicera.dto.UserDTO;
import com.voicera.entity.Appointment;
import com.voicera.feign.DoctorFeignClient;
import com.voicera.feign.UserFeignClient;
import com.voicera.repo.AppointmentRepo;


@Service
public class AppointmentService {

	@Autowired
	private UserFeignClient userFeignClient;
	@Autowired	
	private DoctorFeignClient doctorFeignClient;
	@Autowired
	private AppointmentRepo repo;
	
	
	public Appointment bookNewAppontment(Appointment appointment) {
		
		return repo.save(appointment);
	}
	
	public AppointmentInfoDTO getAppointmentByID(long id) {
		Optional<Appointment> byId = repo.findById(id);  
		if(!byId.isPresent()) {
			return null;
		}
		Appointment appointment = byId.get();
       ResponseEntity<UserDTO> userByID = userFeignClient.getUserByID(appointment.getUserId());
		ResponseEntity<DoctorDTO> doctorById = doctorFeignClient.getDoctorById(appointment.getDoctorId());
		Object userBody = userByID.getBody();
		Object doctorBody = doctorById.getBody();
		UserDTO userDTO = null;
		DoctorDTO doctorDTO=null;
		if (userBody != null&&userBody instanceof UserDTO) {
			userDTO = (UserDTO) userBody;
		}

		if (doctorBody != null && doctorBody instanceof DoctorDTO) {
			doctorDTO = (DoctorDTO) doctorBody;
		}
		
	

		
		AppointmentInfoDTO appointmentInfoDTO = new AppointmentInfoDTO();
		appointmentInfoDTO.setId(appointment.getId());
		appointmentInfoDTO.setPatientname(userDTO.getUsername());
		appointmentInfoDTO.setPatientimage(userDTO.getImagename());
		appointmentInfoDTO.setDoctorname(doctorDTO.getName());
		appointmentInfoDTO.setDepartment(doctorDTO.getDepartment().toString());
		appointmentInfoDTO.setDoctorimage(doctorDTO.getImagename());
		appointmentInfoDTO.setType(doctorDTO.getContactInfo().get(0).getType());
		appointmentInfoDTO.setValue(doctorDTO.getContactInfo().get(0).getValue());
		appointmentInfoDTO.setAppointmentTime(appointment.getAppointmentTime());
		appointmentInfoDTO.setCause(appointment.getCause());

		return appointmentInfoDTO;
	}

}
