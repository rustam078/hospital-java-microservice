package com.voicera.entity;

public enum UserRole {
    ROLE_PATIENT,
    ROLE_DOCTOR,
    ROLE_ADMIN
}
