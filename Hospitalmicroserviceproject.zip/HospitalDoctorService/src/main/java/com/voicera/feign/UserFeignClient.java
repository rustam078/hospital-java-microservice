package com.voicera.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.voicera.dto.UserDTO;

import jakarta.validation.Valid;

@FeignClient(name = "UserService",url = "http://localhost:8081/user-service/api")  // Specify the name of the Feign client
public interface UserFeignClient {

    @PostMapping("/register")  // Replace with the actual endpoint of your User service
    public ResponseEntity<UserDTO> registerUser(@Valid @RequestBody UserDTO userDTO);
}

