package com.voicera.dto;

import com.voicera.entity.AvailableTime;

import lombok.Data;

@Data
public class DoctorAvailableTimeDTO {
    private Long id;
    private AvailableTime availableTime;
    
}