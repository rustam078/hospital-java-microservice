package com.voicera.dto;
public class YourCustomException extends RuntimeException {

    private final String errorMessage;

    public YourCustomException(String errorMessage) {
        super(errorMessage);
        this.errorMessage = errorMessage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
}
