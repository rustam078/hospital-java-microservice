package com.voicera.dto;

import com.voicera.entity.AvailableTime;
import com.voicera.entity.Department;
import com.voicera.entity.Role;

import lombok.Data;

@Data
public class SearchReport {
	private Department department; 
	private Role role;
	private AvailableTime availableTime;
}
