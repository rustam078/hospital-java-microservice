package com.voicera.dto;

import lombok.Data;

@Data
public class RoleDTO {
    private String name;
}
