package com.voicera.dto;

import lombok.Data;

@Data
public class ContactInfoDTO {
    private String type;
    private String value;
}
