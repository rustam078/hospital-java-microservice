package com.voicera.dto;
import java.io.IOException;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import feign.Response;
import feign.Util;
import feign.codec.ErrorDecoder;

public class CustomErrorDecoder implements ErrorDecoder {

    @Override
    public Exception decode(String methodKey, Response response) {
        if (response.status() == HttpStatus.BAD_REQUEST.value()) {
            // Handle specific HTTP error code
            // You can extract more information from the response if needed
            String errorMessage = extractErrorMessage(response);
            return new YourCustomException(errorMessage);
        }

        // You can handle other HTTP error codes similarly

        // For any other error, you can throw a generic exception
        return new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
    }

    private String extractErrorMessage(Response response) {
        try {
            if (response.body() != null) {
                String responseBody = Util.toString(response.body().asReader());
                return responseBody;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "Error message from Feign response";
    }

}
