package com.voicera.repo;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.voicera.entity.ContactInfo;

@Repository
public interface ContactInfoRepository extends JpaRepository<ContactInfo, Long> {

	@Query("SELECT ci FROM ContactInfo ci WHERE ci.doctor.doctor_id IN :doctorIds")
	List<ContactInfo> findAllByDocid(List<Long> doctorIds);

}
