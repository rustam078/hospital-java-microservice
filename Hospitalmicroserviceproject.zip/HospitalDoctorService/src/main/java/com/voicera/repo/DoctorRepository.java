package com.voicera.repo;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.voicera.entity.Department;
import com.voicera.entity.Doctor;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {

	List<Doctor> findByDepartment(Department department);

	Optional<Doctor> findByImagename(String fileName);
	

    @Query("SELECT DISTINCT d.department FROM Doctor d")
    List<String> findDistinctDepartments();

    @Query("SELECT DISTINCT d.role FROM Doctor d")
    List<String> findDistinctRoles();
    
    @Query("SELECT DISTINCT d.availableTime FROM Doctor d")
	List<String> findDistinctAvailableTime();
}
