package com.voicera.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.voicera.dto.DoctorDTO;
import com.voicera.dto.SearchReport;
import com.voicera.entity.AvailableTime;
import com.voicera.entity.Department;
import com.voicera.entity.Doctor;
import com.voicera.entity.Role;
import com.voicera.service.DoctorService;

@RestController
@CrossOrigin
public class DoctorController {
	private static final Logger logger = LoggerFactory.getLogger(DoctorController.class);
	@Autowired
	private DoctorService doctorService;

	@PostMapping("/save")
	public ResponseEntity<?> createDoctor(@ModelAttribute DoctorDTO doctorDTO,
			@RequestParam("file") MultipartFile file) {

		ResponseEntity<?> savedDoctor = doctorService.createDoctor(doctorDTO, file);
		return ResponseEntity.status(savedDoctor.getStatusCode()).body(savedDoctor.getBody());

	}

	@GetMapping("/getAll")
	public List<DoctorDTO> getAllDoctors() {
		logger.info("getAll method got call");
		return doctorService.getAllDoctors();
	}

	@GetMapping("/{doctorId}")
	public ResponseEntity<DoctorDTO> getDoctorById(@PathVariable Long doctorId) {
		Optional<DoctorDTO> optionalDoctorDTO = doctorService.getDoctorById(doctorId);
		return optionalDoctorDTO.map(doctorDTO -> ResponseEntity.ok().body(doctorDTO))
				.orElseGet(() -> ResponseEntity.notFound().build());
	}

	@PutMapping("/{doctorId}")
	public ResponseEntity<DoctorDTO> updateDoctor(@PathVariable Long doctorId, @RequestBody DoctorDTO doctorDTO) {
		DoctorDTO saveDoctor = doctorService.saveDoctor(doctorId, doctorDTO);
		return ResponseEntity.status(HttpStatus.OK).body(saveDoctor);
	}

	@PutMapping("/images/{doctorId}")
	public ResponseEntity<?> updateDoctorImage(@PathVariable Long doctorId, @RequestParam("file") MultipartFile file) {
		return doctorService.saveDoctor(doctorId, file);
	}

	@DeleteMapping("/{doctorId}")
	public ResponseEntity<String> deleteDoctor(@PathVariable Long doctorId) {
		Optional<DoctorDTO> optionalDoctorDTO = doctorService.getDoctorById(doctorId);
		if (optionalDoctorDTO.isPresent()) {
			doctorService.deleteDoctor(doctorId);
			return ResponseEntity.ok("Doctor deleted successfully");
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@GetMapping("/getAll/{fileName}")
	public ResponseEntity<?> downloadImage(@PathVariable String fileName) {
		byte[] imageData = doctorService.downloadImage(fileName);
		return ResponseEntity.status(HttpStatus.OK).contentType(MediaType.valueOf("image/png")).body(imageData);

	}

	@GetMapping("/search")
	public ResponseEntity<?> searchDoctorsByDepartment(@RequestParam("department") Department department) {
		List<DoctorDTO> doctorsByDepartment = doctorService.getDoctorsByDepartment(department);
		return ResponseEntity.ok(doctorsByDepartment);
	}

	@GetMapping("/distinct-available-times")
	public List<String> getDistinctAvailableTimes() {
		return doctorService.getDistinctAvailableTimes();
	}

	@GetMapping("/distinct-departments")
	public List<String> getDistinctDepartments() {
		return doctorService.getDistinctDepartments();
	}

	@GetMapping("/distinct-roles")
	public List<String> getDistinctRoles() {
		return doctorService.getDistinctRoles();
	}


	@GetMapping("/doctors/search")
	public List<DoctorDTO> searchDoctors(@RequestBody SearchReport report) {
		return doctorService.searchAvailableDoctors(report);
	}
	

}
