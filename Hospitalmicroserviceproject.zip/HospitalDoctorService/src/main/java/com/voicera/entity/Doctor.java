package com.voicera.entity;

import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToMany;
import lombok.Data;

@Entity(name = "Doctor")
@Data
public class Doctor {

 

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long doctor_id;

    private String name;
    @OneToMany(mappedBy = "doctor",cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    private List<ContactInfo> contactinfo;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Department department;

    private String imagename;
    
    @Lob
    @Column(name = "image", columnDefinition = "LONGBLOB")
    private byte[] image;

    @Enumerated(EnumType.STRING)
    private AvailableTime availableTime;
 
    @Enumerated(EnumType.STRING)
    private Role role;
    
    @Column(nullable = false)
    private boolean accountActive;
    
    public List<ContactInfo> getContactinfo() {
 		return contactinfo;
 	}

	@Override
	public String toString() {
		return "Doctor [doctor_id=" + doctor_id + ", name=" + name + ", department=" + department + ", imagename="
				+ imagename + ", image=" + Arrays.toString(image) + ", availableTime=" + availableTime + ", role="
				+ role + ", accountActive=" + accountActive + "]";
	}

    
 	
}
