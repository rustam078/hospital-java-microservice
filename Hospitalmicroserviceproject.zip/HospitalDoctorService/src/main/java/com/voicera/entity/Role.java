package com.voicera.entity;

public enum Role {
	DOCTOR,
    STAFF,
    NURSE,
    PHARMACIST,
    LAB_TECHNICIAN,
}