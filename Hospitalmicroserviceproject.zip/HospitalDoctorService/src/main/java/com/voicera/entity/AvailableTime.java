package com.voicera.entity;

public enum AvailableTime {
	   MORNING,
	    AFTERNOON,
	    EVENING,
}
