package com.voicera.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.voicera.dto.ContactInfoDTO;
import com.voicera.dto.DoctorDTO;
import com.voicera.dto.SearchReport;
import com.voicera.entity.ContactInfo;
import com.voicera.entity.Department;
import com.voicera.entity.Doctor;
import com.voicera.repo.ContactInfoRepository;
import com.voicera.repo.DoctorRepository;
import com.voicera.util.DoctorMapper;
import com.voicera.util.ImageUtils;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class DoctorService {
	private static final Logger logger = LoggerFactory.getLogger(DoctorService.class);
	@Autowired
	private DoctorRepository doctorRepository;

	@Autowired
	private ContactInfoRepository contactInfoRepository;
	
	 @Autowired
	    private DoctorMapper doctorMapper;

	public ResponseEntity<?> createDoctor(DoctorDTO doctorDTO,MultipartFile file) {
		byte[] compressImage = null;
		if (file.isEmpty()) {
//			throw new ImageRequiredException("Image fields is Required within max 1mb only");
		}
		try {
			byte[] fileBytes = file.getBytes();
			compressImage = ImageUtils.compressImage(fileBytes);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
            Doctor doctor = convertToEntity(doctorDTO);
            doctor.setImage(compressImage);
            doctor.setAccountActive(true);
            doctor.setImagename(file.getOriginalFilename() + "_" + System.currentTimeMillis());
            Doctor  savedDoctor = doctorRepository.save(doctor);
            if(savedDoctor!=null) {
            	 return ResponseEntity.status(HttpStatus.CREATED).body(doctorDTO);
            	 } else {
                System.out.println("Failed to register user.");
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to register user.");
            }
   
	}
	
	public DoctorDTO saveDoctor(Long doctorid, DoctorDTO updateDoctorDTO) {
	    Optional<Doctor> optionalDoctor = doctorRepository.findById(doctorid);

	    if (optionalDoctor.isPresent()) {
	        Doctor doctorDbValue = optionalDoctor.get();
	        List<ContactInfo> updatedContactInfo = updateContactInfo(doctorDbValue.getContactinfo(), updateDoctorDTO.getContactInfo());
	        copyNonNullProperties(updateDoctorDTO,doctorDbValue);
	        doctorDbValue.setContactinfo(updatedContactInfo);
	        doctorDbValue.getContactinfo().forEach(contactInfo -> contactInfo.setDoctor(doctorDbValue));
	        Doctor savedDoctor = doctorRepository.save(doctorDbValue);

	        return doctorMapper.convertToDTO(savedDoctor);
	    }
	    
	    return null;
	}


 

	private List<ContactInfo> updateContactInfo(List<ContactInfo> contactInfoList, List<ContactInfoDTO> updatedContactInfoList) {
	    Set<String> existingTypes = contactInfoList.stream()
	            .map(ContactInfo::getType)
	            .collect(Collectors.toSet());

	    List<ContactInfo> updatedContactInfo = updatedContactInfoList.stream()
	            .map(updatedInfo -> {
	                boolean typeExists = existingTypes.contains(updatedInfo.getType());

	                if (!typeExists) {
	                    ContactInfo newContactInfo = new ContactInfo();
	                    newContactInfo.setType(updatedInfo.getType());
	                    newContactInfo.setValue(updatedInfo.getValue());
	                    return newContactInfo;
	                }
 
	                return contactInfoList.stream()
	                        .filter(contactInfo -> contactInfo.getType().equals(updatedInfo.getType()))
	                        .findFirst()
	                        .map(existingContactInfo -> {
	                            existingContactInfo.setValue(updatedInfo.getValue());
	                            return existingContactInfo;
	                        })
	                        .orElse(null);
	            })
	            .filter(Objects::nonNull)
	            .collect(Collectors.toList());

	    return updatedContactInfo;
	}


	private void copyNonNullProperties(DoctorDTO src, Doctor target) {
    	BeanUtils.copyProperties(src, target, getNullPropertyNames(src));
	
	}

	
    public static String[] getNullPropertyNames (Object source) {
        final BeanWrapper src = new BeanWrapperImpl(source);
        java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();

        Set<String> emptyNames = new HashSet<String>();
        for(java.beans.PropertyDescriptor pd : pds) {
            Object srcValue = src.getPropertyValue(pd.getName());
            if (srcValue == null) emptyNames.add(pd.getName());
        }
        String[] result = new String[emptyNames.size()];
        return emptyNames.toArray(result);
    }

	public List<DoctorDTO> getAllDoctors() {
        List<Doctor> doctors = doctorRepository.findAll();
        return doctors.stream()
                .map(doctorMapper::convertToDTO)
                .collect(Collectors.toList());
    }

    public Optional<DoctorDTO> getDoctorById(Long doctorId) {
        Optional<Doctor> optionalDoctor = doctorRepository.findById(doctorId);
        return optionalDoctor.map(doctorMapper::convertToDTO);
    }


 
    public void deleteDoctor(Long doctorId) {
        doctorRepository.deleteById(doctorId);
    }

    public List<DoctorDTO> getDoctorsByDepartment(Department department) {
        List<Doctor> doctors = doctorRepository.findByDepartment(department);
        return doctors.stream()
                .map(doctorMapper::convertToDTO)
                .collect(Collectors.toList());
    }

	
	public byte[] downloadImage(String fileName) {
		Optional<Doctor> findByImagename = doctorRepository.findByImagename(fileName);
		byte[] images = ImageUtils.decompressImage(findByImagename.get().getImage());
		return images;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	// Other service methods...

//    private UserDTO getUserDto(Doctor doctor) {
//        UserDTO userDTO = new UserDTO();
//
//        userDTO.setEmail(user.getEmail());
//        userDTO.setUsername(user.getUsername());
//        userDTO.setPassword(user.getPassword());
//        userDTO.setRoles(user.getRoles());
//        return userDTO;
//    }



	private Doctor convertToEntity(DoctorDTO doctorDTO) {
	    Doctor doctor = new Doctor();
	    BeanUtils.copyProperties(doctorDTO, doctor,"contactInfo");

	    if (doctorDTO.getContactInfo() != null && !doctorDTO.getContactInfo().isEmpty()) {
	        List<ContactInfo> contactInfoList = new ArrayList<>();
	        for (ContactInfoDTO contactInfoDTO : doctorDTO.getContactInfo()) {
	            ContactInfo contactInfo = new ContactInfo();
	            BeanUtils.copyProperties(contactInfoDTO, contactInfo);
	            contactInfo.setDoctor(doctor);
	            contactInfoList.add(contactInfo);
	        }
	        doctor.setContactinfo(contactInfoList);
	    }
	    return doctor;
	}


	private DoctorDTO convertToDto(Doctor doctor) {
		DoctorDTO doctorDTO = new DoctorDTO();
		BeanUtils.copyProperties(doctor, doctorDTO);
		return doctorDTO;
	}

	public ResponseEntity<?> saveDoctor(Long doctorId, MultipartFile file) {
			byte[] compressImage = null;
			if (file.isEmpty()) {
//				throw new ImageRequiredException("Image fields is Required within max 1mb only");
			}
			try {
				byte[] fileBytes = file.getBytes();
				compressImage = ImageUtils.compressImage(fileBytes);
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			Optional<Doctor> doctor2 = doctorRepository.findById(doctorId);
			if(!doctor2.isPresent()) {
				return null;
			}
			Doctor doctor = doctor2.get();
	            doctor.setImage(compressImage);
	            doctor.setImagename(file.getOriginalFilename() + "_" + System.currentTimeMillis());
	            Doctor  savedDoctor = doctorRepository.save(doctor);
	            if(savedDoctor!=null) {
	            	 return ResponseEntity.status(HttpStatus.CREATED).body("Image Updated Sucessfully...");
	            	 } else {
	                System.out.println("Failed to Upload Image .");
	                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to Upload image.");
	            }
	   
		}
	
	
	



    public List<String> getDistinctDepartments() {
        return doctorRepository.findDistinctDepartments();
    }

    public List<String> getDistinctRoles() {
        return doctorRepository.findDistinctRoles();
    }
	

	public List<String> getDistinctAvailableTimes() {
		
		return doctorRepository.findDistinctAvailableTime();
	}
 
	

    
	 public List<DoctorDTO> searchAvailableDoctors(SearchReport report) {
	        Doctor doctor = new Doctor();

	        ExampleMatcher matcher = ExampleMatcher.matching()
	                .withIgnoreCase()
	                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
	                .withIgnorePaths("doctor_id", "accountActive", "imagename", "contactinfo", "image");

	        if (report.getAvailableTime() != null) {
	            doctor.setAvailableTime(report.getAvailableTime());
	            matcher = matcher.withMatcher("availableTime", ExampleMatcher.GenericPropertyMatchers.exact());
	        }

	        if (report.getDepartment() != null) {
	            doctor.setDepartment(report.getDepartment());
	            matcher = matcher.withMatcher("department", ExampleMatcher.GenericPropertyMatchers.exact());
	        }

	        if (report.getRole() != null) {
	            doctor.setRole(report.getRole());
	            matcher = matcher.withMatcher("role", ExampleMatcher.GenericPropertyMatchers.exact());
	        }

	        doctor.setAccountActive(true);

	        Example<Doctor> example = Example.of(doctor, matcher);
	       List<Doctor> doctors = doctorRepository.findAll(example);
	       if(doctors.isEmpty()) return null;
	        List<DoctorDTO> collect = doctors.stream()
	                .map(doctorMapper::convertToDTO)
	                .collect(Collectors.toList());
	    
	       return collect;
	    }


	
	
	
	}
	
	
	



