package com.voicera.exception;

public class ImageRequiredException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ImageRequiredException() {
		super();
	}

	public ImageRequiredException(String message) {
		super(message);
	}


}
