package com.voicera.exception;

import lombok.Data;

@Data
public class ErrorResponse {
    private String timestamp;
    private String message;
    private String details;

}
