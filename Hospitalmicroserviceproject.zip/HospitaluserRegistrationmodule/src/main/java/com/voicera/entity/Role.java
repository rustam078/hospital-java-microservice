package com.voicera.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Entity(name="Role")
@Data
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private UserRole name;
    
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user ;
    
//    @JsonCreator
//    public static Role fromJson(@JsonProperty("name") String name) {
//        try {
//            UserRole userRole = UserRole.valueOf(name);  
//            Role role = new Role();
//            role.setName(userRole);
//            return role;
//        } catch (IllegalArgumentException ex) {
//            throw new IllegalArgumentException("Invalid UserRole value: " + name);
//        }
//    }
    



  
}
