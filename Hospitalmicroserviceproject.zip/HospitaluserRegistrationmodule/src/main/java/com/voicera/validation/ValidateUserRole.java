package com.voicera.validation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import jakarta.validation.ReportAsSingleViolation;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


@NotNull(message = "Roles cannot be null")
@Size(min = 1, message = "Roles must have at least one item")
@ReportAsSingleViolation
@Order(Ordered.LOWEST_PRECEDENCE) 
@Target({ElementType.FIELD,ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = UserRoleVaildator.class)
public @interface ValidateUserRole {

	public String message() default "Invalid Role Check it";
	Class<?>[] groups() default { };

	Class<? extends Payload>[] payload() default { };
}
