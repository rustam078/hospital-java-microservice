package com.voicera.validation;

import com.voicera.dto.RoleDTO;
import com.voicera.entity.UserRole;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class UserRoleVaildator implements ConstraintValidator<ValidateUserRole, Iterable<RoleDTO>> {

    @Override
    public boolean isValid(Iterable<RoleDTO> value, ConstraintValidatorContext context) {
        if (value == null) {
            return true; // null values are considered valid
        }

        for (RoleDTO role : value) {
            if (role == null || role.getName() == null || !isValidRole(role.getName())) {
                return false;
            }
        }

        return true;
    }

    private boolean isValidRole(UserRole role) {
        for (UserRole validRole : UserRole.values()) {
            if (validRole.equals(role)) {
                return true;
            }
        }
        return false;
    }
}
