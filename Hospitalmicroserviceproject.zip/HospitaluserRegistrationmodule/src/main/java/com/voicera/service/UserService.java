package com.voicera.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.voicera.dto.RoleDTO;
import com.voicera.dto.UserDTO;
import com.voicera.entity.Role;
import com.voicera.entity.User;
import com.voicera.entity.UserRole;
import com.voicera.exception.ImageRequiredException;
import com.voicera.repo.RoleRepository;
import com.voicera.repo.UserRepository;
import com.voicera.util.ImageUtils;

import jakarta.transaction.Transactional;

@Service
public class UserService {

	private final UserRepository userRepository;
	private final RoleRepository roleRepository;

	private static final ModelMapper modelMapper = new ModelMapper();

	@Autowired
	public UserService(UserRepository userRepository, RoleRepository roleRepository) {
		this.userRepository = userRepository;
		this.roleRepository = roleRepository;
	}

	@Transactional
	public UserDTO saveUser(UserDTO userDTO, MultipartFile file) {
		byte[] compressImage = null;
		if (file.isEmpty()) {
			throw new ImageRequiredException("Image fields is Required within max 1mb only");
		}
		try {
			byte[] fileBytes = file.getBytes();
			compressImage = ImageUtils.compressImage(fileBytes);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		User user = convertToEntity(userDTO);
		user.setImage(compressImage);
		user.setActive(true);
		user.setImagename(file.getOriginalFilename() + "_" + System.currentTimeMillis());
		User save = userRepository.save(user);
		BeanUtils.copyProperties(save, userDTO);
		return userDTO;
	}
	

	private User convertToEntity(UserDTO userDTO) {
       User user = new User();
      BeanUtils.copyProperties(userDTO, user,"roles");
      List<RoleDTO> roles = userDTO.getRoles();
      List<Role> roleList=new ArrayList<>();
      roles.stream().forEach(role->{
    	  Role role2 = new Role();
    	  role2.setName(role.getName());
    	  role2.setUser(user);
    	  roleList.add(role2);
      });
      user.setRoles(roleList);
      return user;
	}

	public byte[] downloadImage(String fileName) {
		Optional<User> findByImagename = userRepository.findByImagename(fileName);
		byte[] images = ImageUtils.decompressImage(findByImagename.get().getImage());
		return images;
	}

	public UserDTO getUserByID(Long id) {
		Optional<User> findById = userRepository.findById(id);
		if (!findById.isPresent())
			return null;
		UserDTO userdto = convertToDTO(findById.get());
//		Set<String> roles = userdto.getRoles();
//		Set<String> roleNames = roles.stream().map(roleString -> {
//			String[] parts = roleString.split(", "); // Assuming string format is "Role [id=..., name=...]"
//			return parts[1].substring(5, parts[1].length() - 1);
//		}).collect(Collectors.toSet());
//		userdto.setRoles(roleNames);
		System.err.println(userdto);
		return userdto;

	}

//	private UserDTO convertEntitytoDto(User user) {
//		UserDTO userDTO = new UserDTO();
//		
//	}

	public static UserDTO convertToDTO(User user) {
		return modelMapper.map(user, UserDTO.class);
	}

	public String deleteUserDetails(String email) {
		User save=null;
		Optional<User> user = userRepository.findByEmail(email);
		if(user.isPresent()) {
			user.get().setActive(false);
			 save = userRepository.save(user.get());
		}
		if(user.get().getId()==save.getId())
		return "Deleted Sucessfully";
		else
			return "Something went wrong try later";
	}

}
