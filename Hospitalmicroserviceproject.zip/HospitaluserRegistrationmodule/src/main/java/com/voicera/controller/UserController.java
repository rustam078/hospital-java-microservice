package com.voicera.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.voicera.dto.UserDTO;
import com.voicera.entity.User;
import com.voicera.service.UserService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }
    
    
    @PostMapping("/hello")
    public String Dummy() {
    	return "Hello";
    }

    @PostMapping("/register")
    public ResponseEntity<UserDTO> registerUser(@Valid @ModelAttribute UserDTO userDTO,@RequestParam("file") MultipartFile file) {
        UserDTO saveUser = userService.saveUser(userDTO,file);
        return ResponseEntity.ok(saveUser);
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<UserDTO> getUserByID(@PathVariable Long id) {
       UserDTO userByID = userService.getUserByID(id);
        return ResponseEntity.ok(userByID);
    }

	@GetMapping("/{fileName}")
	public ResponseEntity<?> downloadImage(@PathVariable String fileName){
		byte[] imageData=userService.downloadImage(fileName);
		return ResponseEntity.status(HttpStatus.OK)
				.contentType(MediaType.valueOf("image/png"))
				.body(imageData);

	}
	
	@DeleteMapping("/delete/{email}")
	public ResponseEntity<?> deleteUserDetails(@PathVariable String email){
	  String deleteUserDetails = userService.deleteUserDetails(email);
		return ResponseEntity.status(HttpStatus.OK).body(deleteUserDetails);
		
	}
	
	 
}
