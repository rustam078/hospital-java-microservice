package com.voicera.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.voicera.entity.Role;
import com.voicera.entity.UserRole;

public interface RoleRepository extends JpaRepository<Role, Long> {

	@Query("SELECT rl FROM Role rl WHERE rl.name IN(:hashSet)")
	List<Role> findByName(List<UserRole> hashSet);

	
}
