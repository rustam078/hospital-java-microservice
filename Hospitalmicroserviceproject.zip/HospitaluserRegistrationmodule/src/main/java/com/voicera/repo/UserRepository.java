package com.voicera.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.voicera.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

	Optional<User> findByImagename(String fileName);

	Optional<User> findByEmail(String email);
 
}
